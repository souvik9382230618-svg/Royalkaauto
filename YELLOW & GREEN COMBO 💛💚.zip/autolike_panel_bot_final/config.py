# config.py — hardcoded configuration (no .env)
BOT_TOKEN = "8344755963:AAE69D0Mp9FDu5KgWA6iJplPzlzwqyXJNb0"
ADMIN_TELEGRAM_IDS = [7968668273]
OUTPUT_GROUP_ID = -1002930088568

PANEL_USERNAME = "admin"
PANEL_PASSWORD = "admin123"

FLASK_SECRET = "ReplaceThisWithARandomLongSecret123!"
LIKE_API = "https://narayan-like27.vercel.app//like?uid={uid}&server_name={region}"
DB_PATH = "data.sqlite3"
