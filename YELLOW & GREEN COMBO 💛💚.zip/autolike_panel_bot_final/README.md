# Autolike Bot + Admin Panel (no .env)

Run:

pip install -r requirements.txt
python app.py

Open http://localhost:10000 and login with the credentials in config.py
